class BaseUrl {
  static const String baseUrl = 'https://flutter-task-server.onrender.com';
}
