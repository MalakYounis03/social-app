import 'package:get/get.dart';

class MainController extends GetxController {
  final index = 0.obs;
  void change(int i) => index.value = i;
}
